# 伐木累分析大师 (Family Analyzer)

> 相亲相爱一家人？让我来扒一扒真相 😏

从微信群聊记录提炼群体人格画像，自动识别：
- 👑 谁才是真正的"话事人"
- 😶 「收到」背后的真实情绪  
- 🗣️ 你们家的专属黑话和暗号
- 🎭 每个成员的角色定位（早安打卡机/转发轰炸机/已读不回/养生专家）

![海报](./poster_fun.png)

## 多平台安装

### 🎯 ClawHub (OpenClaw 用户推荐)
```
clawhub install family-analyzer
```

### 🐍 PyPI (Python 用户)
```bash
pip install family-analyzer
family-analyzer /path/to/群聊.json
```

### 📦 npm (Node.js 用户)
```bash
npm install -g family-analyzer
family-analyzer /path/to/群聊.json
```

### 🔧 MCP (Model Context Protocol)
在 Claude Desktop 或支持 MCP 的客户端配置：
```json
{
  "mcpServers": {
    "family-analyzer": {
      "command": "python3",
      "args": ["/path/to/mcp_server.py"]
    }
  }
}
```

### 🐙 GitHub (源码安装)
```bash
git clone https://github.com/zengury/family-analyzer.git
cd family-analyzer
pip install -r requirements.txt
python3 pipeline/03_extract_kimi_v2.py
```

## 使用教程

### 1. 导出聊天记录
- **微信**: 使用 WeFlow 或其他导出工具，导出为 JSON 格式
- **WhatsApp**: 使用导出功能，保存为文本文件

### 2. 运行分析
```bash
# 设置 API Key
export KIMI_API_KEY="sk-..."

# 运行分析
family-analyzer ~/Downloads/群聊_相亲相爱一家人.json --output ./output
```

### 3. 查看结果
```
output/
├── soul.md          # 群体人格档案
├── persona_妈.md    # 成员个人画像
├── persona_爸.md
└── persona_三姨.md
```

## 技术栈

- **解析层**: Python + 正则表达式处理微信导出格式
- **分析层**: Kimi K2.5 (通过 Anthropic API 兼容接口)
- **输出层**: Markdown 人格档案
- **协议支持**: OpenClaw Skill, MCP Server, CLI Tool

## 成本估算

一份 2-3 年的家庭群聊（约 500 对话块）：
- **ClawHub**: 免费 (使用用户自己的 API Key)
- **自建**: ~¥20-40 一次性 (取决于 Kimi API 定价)

## 方法论

基于**数字民族志** (Digital Ethnography)。

> Geertz 的「厚描」理论：我们不是罗列行为清单，
> 而是构建一个理解这个家庭的解释框架。

输出文件可以直接用于：
- AI Agent 的人格底座
- 家庭回忆录的素材整理
- 群体动力学研究数据

## 案例

### 输入
```json
{
  "timestamp": "2024-01-01 08:00",
  "sender": "妈妈",
  "content": "早上好！今天降温记得多穿点[太阳]"
}
```

### 输出
```markdown
## 成员画像：妈妈

**角色定位**: 早安打卡机

**行为特征**:
- 每日 6:00-8:00 准时发送早安问候
- 关心天气、温度、穿衣提醒
- 使用emoji频率高于文字
- 对家人的生活细节极度关注

**语言特征**:
- 祈使句为主（"记得..."、"别忘了..."）
- 高频词汇：多穿点、早点睡、记得吃饭
```

## 相关项目

- [OpenClaw](https://openclaw.ai) - AI Agent 运行时
- [MCP](https://modelcontextprotocol.io) - Model Context Protocol
- [WeFlow](https://github.com/BlueMatthew/WechatExporter) - 微信聊天记录导出

## License

MIT © [@zengury](https://github.com/zengury)

---

**免责声明**: 本工具仅供娱乐和研究使用。
分析结果可能揭示一些你「不想知道」的家庭真相，请谨慎使用 😂
